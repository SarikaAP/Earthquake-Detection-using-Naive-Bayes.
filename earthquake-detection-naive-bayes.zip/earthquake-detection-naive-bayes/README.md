# Earthquake Detection using Naive Bayes

This project uses a Naive Bayes classifier to predict whether a seismic event is likely to be an earthquake or not, based on features like magnitude, depth, and location.

## 🔍 Dataset
Use a CSV dataset with columns like:
- Magnitude
- Depth
- Latitude
- Longitude
- Target (0 = Non-Earthquake, 1 = Earthquake)

## ⚙️ How to Run

1. Install dependencies:
```
pip install -r requirements.txt
```

2. Run the model:
```
python main.py
```

## 📊 Output
Model accuracy, confusion matrix, and prediction examples will be displayed.
