import pandas as pd
from sklearn.model_selection import train_test_split

def load_and_preprocess_data(file_path):
    df = pd.read_csv(file_path)
    features = df[['Magnitude', 'Depth', 'Latitude', 'Longitude']]
    target = df['Target']  # Earthquake: 1, Non-Earthquake: 0

    return train_test_split(features, target, test_size=0.2, random_state=42)
