from src.preprocess import load_and_preprocess_data
from src.model import train_and_evaluate

if __name__ == "__main__":
    X_train, X_test, y_train, y_test = load_and_preprocess_data("data/earthquake_data.csv")
    train_and_evaluate(X_train, X_test, y_train, y_test)
